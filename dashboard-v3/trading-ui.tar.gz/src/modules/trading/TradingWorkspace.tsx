import { useState, useCallback, useEffect, useRef } from "react";
import { TicketContext } from "@/components/Ticket";
import TradingPage from "@/pages/trading/TradingPage";

export function TradingWorkspace() {
  const [ticketCtx, setTicketCtx] = useState<TicketContext>(null);
  const [positionRefreshKey, setPositionRefreshKey] = useState(0);
  const [gridRefreshKey, setGridRefreshKey] = useState(0);
  const rightPanelRef = useRef<HTMLDivElement>(null);

  const triggerPositionRefresh = useCallback(() => {
    setPositionRefreshKey((k) => k + 1);
  }, []);

  const triggerGridRefresh = useCallback(() => {
    setGridRefreshKey((k) => k + 1);
  }, []);

  const notify = useCallback((msg: string, isError?: boolean) => {
    console.log(`[Notify] ${isError ? 'ERROR' : 'INFO'}: ${msg}`);
    if (isError) {
      console.error(msg);
    }
  }, []);

  // Auto-scroll right panel when ticket context changes (e.g., modal opens)
  useEffect(() => {
    if (ticketCtx && rightPanelRef.current) {
      // Smooth scroll to top of right panel when modal opens
      rightPanelRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [ticketCtx]);

  // Auto-adjust panel heights on window resize
  useEffect(() => {
    const handleResize = () => {
      // Ensure panels maintain proper proportions
      const windowHeight = window.innerHeight;
      const chartHeight = Math.max(400, windowHeight * 0.4);
      
      // Update CSS variables for dynamic sizing
      document.documentElement.style.setProperty('--chart-height', `${chartHeight}px`);
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="h-full w-full p-4 overflow-hidden">
      <div className="flex flex-col h-full gap-4">
        <div className="flex-1 min-h-0">
          <TradingPage
            ticketCtx={ticketCtx}
            setTicketCtx={setTicketCtx}
            positionRefreshKey={positionRefreshKey}
            gridRefreshKey={gridRefreshKey}
            triggerPositionRefresh={triggerPositionRefresh}
            triggerGridRefresh={triggerGridRefresh}
            notify={notify}
          />
        </div>
        
        {/* Right panel with auto-scroll */}
        <div 
          ref={rightPanelRef}
          className="overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-800"
          style={{ maxHeight: 'calc(100vh - 100px)' }}
        >
          {/* Content will auto-scroll when needed */}
        </div>
      </div>
    </div>
  );
}
