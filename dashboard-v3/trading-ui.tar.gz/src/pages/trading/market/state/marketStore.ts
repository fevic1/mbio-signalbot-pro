import { create } from "zustand";

export interface Candle {
  time:number;
  open:number;
  high:number;
  low:number;
  close:number;
  volume:number;
}

interface MarketState {

candles:Record<string,Candle[]>;

setCandles:(symbol:string,candles:Candle[])=>void;

appendCandle:(symbol:string,candle:Candle)=>void;

}

export const useMarketStore =
create<MarketState>((set)=>({

candles:{},

setCandles:(symbol,candles)=>
set(state=>({
candles:{
 ...state.candles,
 [symbol]:candles
}
})),

appendCandle:(symbol,candle)=>
set(state=>({

candles:{
 ...state.candles,
 [symbol]:[
   ...(state.candles[symbol] ?? []),
   candle
 ]
}

}))

}));
