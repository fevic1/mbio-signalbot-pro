import { create } from "zustand";

export interface ChartInstance {
  id:string;
  symbol:string;
  timeframe:string;
}

interface ChartState {

charts:ChartInstance[];

setChartSymbol:(id:string,symbol:string)=>void;

setTimeframe:(id:string,timeframe:string)=>void;

}

export const useChartStore =
create<ChartState>((set)=>({

charts:[
 {
  id:"chart-1",
  symbol:"BTC-PERP",
  timeframe:"15m"
 },
 {
  id:"chart-2",
  symbol:"ETH-PERP",
  timeframe:"1h"
 },
 {
  id:"chart-3",
  symbol:"SOL-PERP",
  timeframe:"5m"
 },
 {
  id:"chart-4",
  symbol:"BTC-PERP",
  timeframe:"1h"
 }
],

setChartSymbol:(id,symbol)=>
set(state=>({
charts:
state.charts.map(chart=>
chart.id===id
?
{
 ...chart,
 symbol
}
:
chart
)
})),


setTimeframe:(id,timeframe)=>
set(state=>({
charts:
state.charts.map(chart=>
chart.id===id
?
{
 ...chart,
 timeframe
}
:
chart
)
}))

}));
