import { useState, useCallback } from 'react';
import { useResizable } from '@/hooks/useResizable';
import { useKeyboardShortcuts } from '@/hooks/useKeyboardShortcuts';
import { DragHandle } from '@/components/DragHandle';
import { cn } from '@/lib/utils';

interface TradingTerminalProps {
  leftPanel: React.ReactNode;
  centerPanel: React.ReactNode;
  rightPanel: React.ReactNode;
}

export function TradingTerminal({
  leftPanel,
  centerPanel,
  rightPanel,
}: TradingTerminalProps) {
  const [leftCollapsed, setLeftCollapsed] = useState(false);
  const [rightCollapsed, setRightCollapsed] = useState(false);

  const leftResizable = useResizable({
    initialWidth: 320,
    minWidth: 300,
    maxWidth: 450,
    storageKey: 'trading-left-width',
  });

  const rightResizable = useResizable({
    initialWidth: 380,
    minWidth: 360,
    maxWidth: 420,
    storageKey: 'trading-right-width',
  });

  const toggleLeftPanel = useCallback(() => {
    setLeftCollapsed(prev => !prev);
  }, []);

  const toggleRightPanel = useCallback(() => {
    setRightCollapsed(prev => !prev);
  }, []);

  const maximizeChart = useCallback(() => {
    setLeftCollapsed(true);
    setRightCollapsed(true);
  }, []);

  useKeyboardShortcuts({
    toggleLeftPanel,
    toggleRightPanel,
    maximizeChart,
  });

  return (
    <div className="flex h-full w-full overflow-hidden bg-background">
      {/* Left Panel */}
      <div
        className={cn(
          'panel-transition flex-shrink-0 overflow-hidden',
          leftCollapsed ? 'w-12' : ''
        )}
        style={{ width: leftCollapsed ? undefined : `${leftResizable.width}px` }}
      >
        {leftPanel}
      </div>

      {/* Left Drag Handle */}
      {!leftCollapsed && (
        <DragHandle
          onMouseDown={leftResizable.handleMouseDown}
          onDoubleClick={leftResizable.handleDoubleClick}
        />
      )}

      {/* Center Panel */}
      <div className="flex-1 min-w-0 overflow-hidden">
        {centerPanel}
      </div>

      {/* Right Drag Handle */}
      {!rightCollapsed && (
        <DragHandle
          onMouseDown={rightResizable.handleMouseDown}
          onDoubleClick={rightResizable.handleDoubleClick}
        />
      )}

      {/* Right Panel */}
      <div
        className={cn(
          'panel-transition flex-shrink-0 overflow-hidden',
          rightCollapsed ? 'w-12' : ''
        )}
        style={{ width: rightCollapsed ? undefined : `${rightResizable.width}px` }}
      >
        {rightPanel}
      </div>
    </div>
  );
}
