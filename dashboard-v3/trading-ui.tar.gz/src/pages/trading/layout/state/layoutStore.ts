import { create } from "zustand";

export type LayoutMode =
  | "single"
  | "double"
  | "quad";

interface LayoutState {

  mode: LayoutMode;

  setMode:(mode:LayoutMode)=>void;

}

export const useLayoutStore =
create<LayoutState>((set)=>({

mode:"single",

setMode:(mode)=>
set({
 mode
})

}));
