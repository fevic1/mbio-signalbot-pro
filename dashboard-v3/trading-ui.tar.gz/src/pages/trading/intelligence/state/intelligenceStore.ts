import { create } from "zustand";

import {
  TradeSetup
} from "../types";


interface IntelligenceState {

latestSetup: TradeSetup | null;

setSetup:(setup:TradeSetup|null)=>void;

}


export const useIntelligenceStore =
create<IntelligenceState>((set)=>({

latestSetup:null,

setSetup:(setup)=>
set({
latestSetup:setup
})

}));
