import { create } from "zustand";

import {
  AgentDecision
} from "../types";


interface VotingState {

decisions:AgentDecision[];

consensus:{
 decision:string;
 confidence:number;
}|null;


setVoting:(

decisions:AgentDecision[],

consensus:{
 decision:string;
 confidence:number;
}

)=>void;

}


export const useVotingStore =
create<VotingState>((set)=>({

decisions:[],

consensus:null,


setVoting:(decisions,consensus)=>
set({

decisions,

consensus

})

}));
