import { useState } from "react";
import { Ticket, TicketContext } from "@/components/Ticket";
import { BotsMiniList } from "@/components/BotsMiniList";
import { CandleChart } from "@/modules/markets/CandleChart";
import { PositionsPanel } from "@/modules/portfolio/PositionsPanel";
import { TradingTerminal } from "./layout/TradingTerminal";

type Props = {
  ticketCtx: TicketContext;
  setTicketCtx: (ctx: TicketContext) => void;
  positionRefreshKey: number;
  gridRefreshKey: number;
  triggerPositionRefresh: () => void;
  triggerGridRefresh: () => void;
  notify: (msg: string, isError?: boolean) => void;
};

const TABS = [
  "Positions",
  "Orders",
  "Signals",
  "History",
  "AI",
  "Logs",
  "Alerts",
] as const;

export default function TradingPage({
  ticketCtx,
  setTicketCtx,
  positionRefreshKey,
  gridRefreshKey,
  triggerPositionRefresh,
  triggerGridRefresh,
  notify,
}: Props) {
  const [activeTab, setActiveTab] = useState<(typeof TABS)[number]>("Positions");

  // Left Panel: Running Bots
  const leftPanel = (
    <div className="flex h-full flex-col bg-card border-r border-border">
      <div className="sticky-header px-4 py-3">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Running Bots
        </h3>
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        <BotsMiniList
          refreshKey={gridRefreshKey}
          onCloseGrid={(asset: string) =>
            setTicketCtx({ type: "close_grid", asset })
          }
          onCloseDca={(asset: string) =>
            setTicketCtx({ type: "close_dca", asset })
          }
        />
      </div>
    </div>
  );

  // Center Panel: Chart + Bottom Workspace
  const centerPanel = (
    <div className="flex h-full flex-col bg-background">
      {/* Chart Section */}
      <div className="h-[60%] border-b border-border">
        <CandleChart />
      </div>
      
      {/* Bottom Workspace Section */}
      <div className="flex min-h-0 flex-1 flex-col bg-card">
        <div className="sticky-header flex border-b border-border overflow-x-auto">
          {TABS.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 text-xs font-medium whitespace-nowrap transition-colors ${
                activeTab === tab
                  ? "border-b-2 border-primary text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-4">
          {activeTab === "Positions" ? (
            <PositionsPanel
              refreshKey={positionRefreshKey}
              onClose={(pos) =>
                setTicketCtx({
                  type: "close_position",
                  asset: pos.asset,
                  side: pos.side,
                  size: pos.size,
                })
              }
            />
          ) : (
            <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
              {activeTab} coming soon
            </div>
          )}
        </div>
      </div>
    </div>
  );

  // Right Panel: QT Parameters (Ticket/Builder)
  const rightPanel = (
    <div className="flex h-full flex-col bg-card border-l border-border">
      <div className="sticky-header px-4 py-3 flex items-center justify-between">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          QT Parameters
        </h3>
        {ticketCtx && (
          <button 
            onClick={() => setTicketCtx(null)}
            className="text-muted-foreground hover:text-foreground text-lg leading-none transition-colors"
          >
            ✕
          </button>
        )}
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        <Ticket
          context={ticketCtx}
          onClose={() => setTicketCtx(null)}
          onResult={(msg: string, err: boolean) => {
            notify(msg, err);
            if (!err) setTicketCtx(null);
          }}
          triggerRefresh={triggerPositionRefresh}
          triggerGridRefresh={triggerGridRefresh}
          onChooseBotType={(t: "grid" | "dca") =>
            setTicketCtx(t === "grid" ? { type: "open_grid" } : { type: "open_dca" })
          }
          botsListProps={undefined}
        />
      </div>
      <div className="sticky-footer px-4 py-3">
        <button
          className="w-full h-10 rounded-md bg-primary font-medium text-primary-foreground hover:bg-primary/90 transition-colors text-sm"
          onClick={() => setTicketCtx({ type: "create_bot_choice" })}
        >
          + Create Bot
        </button>
      </div>
    </div>
  );

  return (
    <TradingTerminal
      leftPanel={leftPanel}
      centerPanel={centerPanel}
      rightPanel={rightPanel}
    />
  );
}
