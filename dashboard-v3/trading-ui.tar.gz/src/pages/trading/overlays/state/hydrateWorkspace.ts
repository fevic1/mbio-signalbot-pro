import { useOverlayStore } from "./overlayStore";
import { loadOverlayWorkspace } from "./workspaceStorage";

export function hydrateOverlayWorkspace(){

const workspace =
loadOverlayWorkspace();


if(!workspace?.activeGroups){
 return;
}


useOverlayStore.setState({

activeGroups:
workspace.activeGroups

});

}
