import { create } from "zustand";
import { saveOverlayWorkspace } from "./workspaceStorage";

interface OverlayState {

  activeGroups: string[];

  toggleGroup:(group:string)=>void;

  enableAll:()=>void;

  disableAll:()=>void;

}

export const useOverlayStore = create<OverlayState>((set)=>({

activeGroups:[
  "institutional",
  "market-profile",
  "volume"
],

toggleGroup:(group)=>{

set(state=>{

const activeGroups =
state.activeGroups.includes(group)
?
state.activeGroups.filter(x=>x!==group)
:
[
 ...state.activeGroups,
 group
];

saveOverlayWorkspace(activeGroups);

return {
 activeGroups
};

});

},


enableAll:()=>{

const activeGroups=[
"institutional",
"ict",
"market-profile",
"volume",
"execution",
"risk"
];

saveOverlayWorkspace(activeGroups);

set({
 activeGroups
});

},


disableAll:()=>{

const activeGroups:string[]=[];

saveOverlayWorkspace(activeGroups);

set({
 activeGroups
});

}

}));
