const KEY = "trading-overlay-workspace";

export function saveOverlayWorkspace(
  activeGroups:string[]
){

localStorage.setItem(
 KEY,
 JSON.stringify({
  activeGroups,
  savedAt:new Date().toISOString()
 })
);

}


export function loadOverlayWorkspace(){

const data =
localStorage.getItem(KEY);

if(!data){
 return null;
}

return JSON.parse(data);

}


export function clearOverlayWorkspace(){

localStorage.removeItem(KEY);

}
