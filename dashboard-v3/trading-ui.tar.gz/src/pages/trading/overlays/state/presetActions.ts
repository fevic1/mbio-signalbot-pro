import { useOverlayStore } from "./overlayStore";
import { overlayPresets } from "../presets";

export function loadOverlayPreset(
  preset:keyof typeof overlayPresets
){

const groups =
overlayPresets[preset];

useOverlayStore.setState({

activeGroups:groups

});

}
